/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tn.esprit.entity;

/**
 *
 * @author Asus
 */
public enum TypeActivite {
        Yoga,
        Rapide,
        Etirer,
        Au_bureau,
        Au_lit
}

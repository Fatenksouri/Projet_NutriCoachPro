
import entity.Categorie;
import entity.Convention;
import entity.Offre;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import services.ServiceConvention;
import services.ServiceOffre;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author omnia
 */
public class main {
    public static void main(String[] args) {
       
        ServiceConvention sc = new ServiceConvention();
        
        ServiceOffre so = new ServiceOffre();
        

        
    }
}

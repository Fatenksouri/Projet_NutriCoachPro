-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le :  mer. 09 mars 2022 à 21:51
-- Version du serveur :  8.0.18
-- Version de PHP :  7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mokhtarpidev`
--

-- --------------------------------------------------------

--
-- Structure de la table `reclamation`
--

CREATE TABLE `reclamation` (
  `idreclamation` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `description` varchar(500) NOT NULL,
  `sujet` varchar(500) NOT NULL,
  `etat` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `Montant` float NOT NULL
)  ;

--
-- Déchargement des données de la table `reclamation`
--

INSERT INTO `reclamation` (`idreclamation`, `iduser`, `type`, `description`, `sujet`, `etat`, `image`, `Montant`) VALUES
(51, 1, 'GDF', 'GRG', 'GEGE', 'Approuvée', 'C:\\Users\\Mejri Wajih\\Downloads\\NoImage.png', 22),
(52, 1, 'FEA', 'FEAF', 'FEA', 'Approuvée', 'C:\\Users\\Mejri Wajih\\Downloads\\NoImage.png', 34),
(53, 1, 'GEA', 'FEA', 'AAA', 'En Cours', 'C:\\Users\\Mejri Wajih\\Downloads\\274049228_319018746947221_5581969381394291701_n.jpg', 34);

-- --------------------------------------------------------

--
-- Structure de la table `remboursement`
--

CREATE TABLE `remboursement` (
  `id` int(11) NOT NULL,
  `prixtotal` float NOT NULL,
  `idreclamation` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `etat` varchar(20) NOT NULL
)  ;

--
-- Déchargement des données de la table `remboursement`
--

INSERT INTO `remboursement` (`id`, `prixtotal`, `idreclamation`, `iduser`, `etat`) VALUES
(1, 22, 51, 1, 'Approuvée'),
(2, 20, 52, 1, 'Approuvée');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `reclamation`
--
ALTER TABLE `reclamation`
  ADD PRIMARY KEY (`idreclamation`);

--
-- Index pour la table `remboursement`
--
ALTER TABLE `remboursement`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_remboursement` (`idreclamation`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `reclamation`
--
ALTER TABLE `reclamation`
  MODIFY `idreclamation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT pour la table `remboursement`
--
ALTER TABLE `remboursement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `remboursement`
--
ALTER TABLE `remboursement`
  ADD CONSTRAINT `fk_remboursement` FOREIGN KEY (`idreclamation`) REFERENCES `reclamation` (`idreclamation`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
